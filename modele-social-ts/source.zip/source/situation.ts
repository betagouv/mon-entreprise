import { SituationEntreprise } from './entreprise/situation'
import { Commune } from './territoire'

export interface Situation {
	commune?: Commune
	catégorieJuridique?: string
}

export interface SituationAvecEntreprise extends Situation {
	entreprise: SituationEntreprise
}
