import { SituationSalarié } from '../situation'
import { Montant } from '../../Montant'

export const getAssietteDeCotisations = (situation: SituationSalarié): Montant
																				 => getSalaireBrut( situation )
