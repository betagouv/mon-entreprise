import { Situation } from '../situation'
import { SituationSalarié } from './situation'

interface Question<T, S extends Situation> {
	applicable: (situation: S) => boolean
	répond: (situation: S, data: T) => S
	estRépondue: (situation: S) => boolean
}

const éligibleLodeomÉligibleInnovationEtCroissance: Question<
	boolean,
	SituationSalarié
> = {
	applicable: (situation) => !!situation.salaire,
	répond: (situation, éligible: boolean) => ({
		...situation,
		entreprise: {
			...situation.entreprise,
			activité: {
				...situation.entreprise.activité,
				éligibleLodeomÉligibleInnovationEtCroissance: éligible,
			},
		},
	}),
	estRépondue: (situation) =>
		undefined !==
		situation.entreprise.activité.éligibleLodeomÉligibleInnovationEtCroissance,
}

const questionsSalarié: Array<Question<unknown, SituationSalarié>> = []

declare const situationCourante: SituationSalarié
declare const JeLaPose: () => void
declare const nextQuestion: () => void

questionsSalarié.forEach((question) => {
	if (question.applicable(situationCourante)) {
		JeLaPose()
	}

	nextQuestion()
})
