import { Situation, SituationAvecEntreprise } from '../situation'
import { Salaire } from './salaireBrut'

export interface SituationSalarié extends Situation, SituationAvecEntreprise {
	salaire: Salaire
	catégorieJuridique: "Entreprise"
}

declare const s: SituationSalarié

import { Salarié } for
