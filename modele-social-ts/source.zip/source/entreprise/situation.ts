import { ChiffreDAffairesAnnuel } from './ChiffreDAffaires'
import { Effectif } from './Effectif'

export interface SituationEntreprise {
	effectif: Effectif
	chiffreDAffaires: ChiffreDAffairesAnnuel
	activité: {
		éligibleLodeomÉligibleInnovationEtCroissance?: boolean
	}
}
