import { Montant } from '../Montant'
import { SituationSalarié } from './situation'

interface SalaireBrut {
	_tag: 'salaire_brut'
	brut: Montant
}

interface SalaireNet {
	_tag: 'salaire_net'
	net: Montant
}

export type Salaire = SalaireBrut | SalaireNet

export const getSalaireBrut = (situation: SituationSalarié): Montant =>
	situation.salaire
