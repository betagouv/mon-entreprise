import { all, and } from 'effect/Predicate'

import {
	aChiffreDAffairesAnnuelInférieurÀ,
	ChiffreDAffairesAnnuel,
} from '../../../entreprise/ChiffreDAffaires'
import { aEffectifInférieurÀ, Effectif } from '../../../entreprise/Effectif'
import { SituationEntreprise } from '../../../entreprise/situation'
import { Départements, estDépartement } from '../../../territoire/département'
import { SituationSalarié } from '../../situation'

/**
 * Zone géographique 1 (Guadeloupe, Martinique, La Réunion, Guyane)
 *
 * @param situation
 */
const estZone1 = (situation: SituationSalarié) => {
	return (
		estDépartement(situation.commune, Départements.Guadeloupe) ||
		estDépartement(situation.commune, Départements.Martinique)
		// TODO les autres
	)
}

const seuilInflexion = (situation: SituationSalarié): number => {
	if (estZone1(situation)) {
	}
}

interface Barème {
	nom: string
	estÉligible: (entreprise: SituationEntreprise) => boolean
}

const BarèmeCompétitivité = 'Compétivité'

/**
 * Barème compétitivité renforcée
 *
 * - Chiffre d'affaires de moins de 50 millions d'euros
 * - Les employeurs relevant des secteurs de l’industrie, de la restauration, de l’environnement, de l’agro nutrition, des énergies renouvelables, des nouvelles technologies de l’information et de la communication et des centres d’appel, de la pêche, des cultures marines, de l’aquaculture, de l’agriculture, du tourisme y compris les activités de loisirs s’y rapportant, du nautisme, de l’hôtellerie, de la recherche et du développement ;
 * - Les entreprises bénéficiaires du régime de perfectionnement actif défini à l’article 256 du règlement (UE) n° 952/2013 du parlement européen et du conseil du 9 octobre 2013 établissant le code des douanes de l’Union
 * - En Guyane, les employeurs ayant une activité principale relevant de l’un des secteurs d’activité éligibles à la réduction d’impôt prévue à l’article 199 undecies B du code général des impôts, ou correspondant à l’une des activités suivantes : comptabilité, conseil aux entreprises, ingénierie ou études techniques.
 *
 * @see Fiche Urssaf: https://www.urssaf.fr/portail/home/outre-mer/employeur/exoneration-de-cotisations-di-1/employeurs-situes-en-guadeloupe/bareme-dit-de-competitivite-renf.html
 */
const BarèmeCompétitivitéRenforcée = {
	nom: 'Compétivité renforcée',
	estÉligible: and(
		aEffectifInférieurÀ(Effectif(250)),
		aChiffreDAffairesAnnuelInférieurÀ(ChiffreDAffairesAnnuel(50_000_000))
	),
} as const satisfies Barème

const aUneActivitéÉligibleInnovationEtCroissance = (
	entreprise: SituationEntreprise
) => entreprise.activité.éligibleLodeomÉligibleInnovationEtCroissance

/**
 *  Barème innovation et croissance
 *
 *  Sont éligibles à ce barème les employeurs occupant moins de 250 salariés et ayant réalisé un chiffre d’affaires annuel inférieur à 50 millions d’euros, au titre de la rémunération des salariés concourant essentiellement à la réalisation de projets innovants dans le domaine des technologies de l’information et de la communication.
 *
 *  Les projets innovants se définissent comme des projets ayant pour but l’introduction d’un bien, d’un service, d’une méthode de production ou de distribution nouveau ou sensiblement amélioré sur le plan des caractéristiques et de l’usage auquel il est destiné. Ces projets doivent être réalisés dans les domaines suivants :
 *    - télécommunication ;
 *    - informatique, dont notamment programmation, conseil en systèmes et logiciels, tierce maintenance de systèmes et d’applications, gestion d‘installations, traitement des données, hébergement et activités connexes ;
 *    - édition de portails internet et de logiciels;
 *    - infographie, notamment conception de contenus visuels et numériques ;
 *    - conception d’objets connectés.
 *    - Si ces conditions sont réunies, l’exonération s’applique aux rémunérations versées aux salariés occupés principalement à la réalisation de projets innovants.
 *    - Sont donc exclues les fonctions supports : tâches administratives financières, logistiques et de ressources humaines.
 *
 *  @see Fiche Urssaf: https://www.urssaf.fr/portail/home/outre-mer/employeur/exoneration-de-cotisations-di-1/employeurs-situes-en-guadeloupe/bareme-dit-innovation-et-croissa.html
 */
const BarèmeInnovationEtCroissance = {
	nom: 'Innovation et croissance',
	estÉligible: (entrerise) =>
		all([
			aEffectifInférieurÀ(Effectif(250)),
			aChiffreDAffairesAnnuelInférieurÀ(ChiffreDAffairesAnnuel(50_000_000)),
			aUneActivitéÉligibleInnovationEtCroissance,
		])(entrerise),
} as const satisfies Barème

const AucunBarème = 'AucunBarème'

type BarèmeLodeom =
	| typeof BarèmeCompétitivité
	| typeof BarèmeCompétitivitéRenforcée
	| typeof BarèmeInnovationEtCroissance.nom
	| typeof AucunBarème

const getBarème = (situation: SituationSalarié): BarèmeLodeom => {
	if (BarèmeInnovationEtCroissance.estÉligible(situation.entreprise)) {
		return BarèmeInnovationEtCroissance.nom
	}

	return AucunBarème
}
