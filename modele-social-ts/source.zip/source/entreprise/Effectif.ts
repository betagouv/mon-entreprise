import { Brand } from 'effect'
import { dual } from 'effect/Function'

import { SituationEntreprise } from './situation'

export type Effectif = number & Brand.Brand<'Effectif'>
export const Effectif = Brand.refined<Effectif>(
	(n) => Number.isInteger(n) && n >= 0,
	(n) => Brand.error(`${n} n'est pas un effectif valide`)
)

export const aEffectifInférieurÀ = dual<
	(effectif: Effectif) => (situationEntreprise: SituationEntreprise) => boolean,
	(situationEntreprise: SituationEntreprise, plafond: Effectif) => boolean
>(
	2,
	(situationEntreprise: SituationEntreprise, plafond: Effectif) =>
		situationEntreprise.effectif <= plafond
)
