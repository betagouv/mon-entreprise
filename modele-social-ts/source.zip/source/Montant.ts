import { Brand } from 'effect'

export type Montant = number & Brand.Brand<'Montant'>

export const Montant = Brand.nominal<Montant>()
