import { Brand } from 'effect'
import { dual } from 'effect/Function'

import { SituationEntreprise } from './situation'

export type ChiffreDAffairesAnnuel = number &
	Brand.Brand<'Entreprise.ChiffreDAffairesAnnuel'>
export const ChiffreDAffairesAnnuel = Brand.refined<ChiffreDAffairesAnnuel>(
	(n) => n >= 0,
	(n) => Brand.error(`${n} n'est pas un chiffre d’affaires valide`)
)

export const aChiffreDAffairesAnnuelInférieurÀ = dual<
	(
		effectif: ChiffreDAffairesAnnuel
	) => (situationEntreprise: SituationEntreprise) => boolean,
	(
		situationEntreprise: SituationEntreprise,
		effectif: ChiffreDAffairesAnnuel
	) => boolean
>(
	2,
	(situationEntreprise: SituationEntreprise, plafond: ChiffreDAffairesAnnuel) =>
		situationEntreprise.effectif <= plafond
)
