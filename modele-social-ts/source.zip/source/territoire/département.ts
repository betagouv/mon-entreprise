import { dual } from 'effect/Function'

import { CodePostal } from '../territoire'

export const Départements = defineDépartements({
	Guadeloupe: {
		code: '971',
		nom: 'Guadeloupe',
	},
	Martinique: {
		code: '971',
		nom: 'Martinique',
	},
	// TODO les autres
})

export type Département = (typeof Départements)[keyof typeof Départements]

const equals = (
	département1: Département,
	département2: Département
): boolean => département1.code === département2.code

export const estDépartement = dual<
	(département: Département) => (codePostal: CodePostal) => boolean,
	(codePostal: CodePostal, département: Département) => boolean
>(2, (codePostal: CodePostal, département: Département): boolean => {
	const found = Object.values(Départements).find((département) =>
		codePostal.startsWith(département.code)
	)

	if (!found) {
		return false
	}

	return equals(found, département)
})

function defineDépartements<
	T extends Record<string, { code: string; nom: keyof T }>,
>(départements: T): T {
	return départements
}
